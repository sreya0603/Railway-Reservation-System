1.first run admin.java for releaseing the trains by admin
2.copy the code in sqlproject and load it into database(postgres)
3.change the username ,port, username of database in sql java connection accordingly in servicemodule.java and admin.java files
4.then compile ServiceModule.java and run ServiceModule.java
5.similarly compile and run client.java.
6.you will get output in the output file.
